package com.example.notatniczek.controller;


import com.example.notatniczek.model.Note;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {

    @MessageMapping("/editNote")
    @SendTo("/topic/noteUpdates")
    public Note editNote(Note note) {
        // Note service logic to save note
        return note;
    }

}
