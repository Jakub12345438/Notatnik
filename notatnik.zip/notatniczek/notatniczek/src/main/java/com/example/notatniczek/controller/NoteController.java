package com.example.notatniczek.controller;

import com.example.notatniczek.model.Note;
import com.example.notatniczek.service.NoteService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/note")
@AllArgsConstructor
public class NoteController {

    private NoteService noteService;

    @GetMapping("/list")
    public String getAllNotes(Authentication authentication, Model model) {
        Long userId = (Long) authentication.getPrincipal();
        List<Note> notes = noteService.getAllNotes(userId);
        model.addAttribute("notes", notes);
        return "note/list";
    }

    @GetMapping("/note/{id}")
    public String getNoteById(@PathVariable Long id, Model model) {
        Note note = noteService.getNoteById(id);
        model.addAttribute("note", note);
        return "note/view";
    }

    @PostMapping("/addNote")
    public String createOrUpdateNote(@ModelAttribute Note note) {
        noteService.createOrUpdateNote(note);
        return "redirect:/note";
    }

    @DeleteMapping("/deleteNote/{id}")
    public String deleteNoteById(@PathVariable Long id) {
        noteService.deleteNoteById(id);
        return "redirect:/note";
    }

}
